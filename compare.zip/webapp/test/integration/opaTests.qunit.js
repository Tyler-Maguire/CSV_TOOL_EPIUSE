/* global QUnit */

sap.ui.require(["com/epiuse/compare/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
