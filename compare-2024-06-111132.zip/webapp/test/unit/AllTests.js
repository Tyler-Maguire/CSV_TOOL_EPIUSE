sap.ui.define([
	"comepiuse/compare/test/unit/controller/appView.controller"
], function () {
	"use strict";
});
